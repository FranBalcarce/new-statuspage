import {
  CognitoIdentityClient,
  GetIdCommand,
  GetCredentialsForIdentityCommand,
} from "https://cdn.jsdelivr.net/npm/@aws-sdk/client-cognito-identity/+esm";

import {
  HealthClient,
  DescribeEventsCommand,
} from "https://cdn.jsdelivr.net/npm/@aws-sdk/client-health/+esm";

// Configuración
const REGION = "us-east-2";
const IDENTITY_POOL_ID = "us-east-2_irSuSW7ld"; // <-- reemplazá esto

async function obtenerEventos() {
  const identityClient = new CognitoIdentityClient({ region: REGION });

  const { IdentityId } = await identityClient.send(new GetIdCommand({
    IdentityPoolId: IDENTITY_POOL_ID,
  }));

  const { Credentials } = await identityClient.send(
    new GetCredentialsForIdentityCommand({ IdentityId })
  );

  const healthClient = new HealthClient({
    region: REGION,
    credentials: {
      accessKeyId: Credentials.AccessKeyId,
      secretAccessKey: Credentials.SecretKey,
      sessionToken: Credentials.SessionToken,
    },
  });

  const result = await healthClient.send(new DescribeEventsCommand({}));
  return result.events;
}

function renderGrafico(data) {
  const ctx = document.getElementById("grafico").getContext("2d");
  new Chart(ctx, {
    type: "pie",
    data: {
      labels: Object.keys(data),
      datasets: [{
        data: Object.values(data),
        backgroundColor: ["#facc15", "#16a34a", "#ef4444"]
      }]
    }
  });
}

// Acá procesás el token de Cognito
function getTokenFromURL() {
  const hash = window.location.hash;
  const params = new URLSearchParams(hash.slice(1));
  return params.get('id_token'); // o 'access_token' si usás ese
}

const token = getTokenFromURL();
if (token) {
  console.log("Token recibido:", token);
  // Podés guardar en localStorage y usarlo para autorizar futuras peticiones
  // localStorage.setItem("jwt", token);
}

obtenerEventos()
  .then(events => {
    const contenedor = document.getElementById("servicios");
    const estados = {};

    events.forEach(evt => {
      const estado = evt.statusCode;
      estados[estado] = (estados[estado] || 0) + 1;

      const div = document.createElement("div");
      div.innerHTML = `<strong>${evt.service}</strong> - ${estado}`;
      contenedor.appendChild(div);
    });

    renderGrafico(estados);
  })
  .catch(console.error);
